import React from 'react';

export default function Pnf(props) {
    return (
        <div className="container">
            <div className="pnf">
                <h1>Requested Path Not Found</h1>
                <h2>404 Error</h2>
            </div>
        </div>
    )
}