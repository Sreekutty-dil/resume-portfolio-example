import React from 'react';

export default function About(props) {
    return(
        <div className="container">
            <h1>About Page</h1>
        </div>
    )
}