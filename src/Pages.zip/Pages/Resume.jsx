import React from 'react';

export default function Resume(props) {
    return(
        <div className="container">
            <h1>Resume Page</h1>
        </div>
    )
}