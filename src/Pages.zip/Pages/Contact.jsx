import React from 'react';

export default function Contact(props) {
    return(
        <div className="container">
            <h1>Contact Page</h1>
        </div>
    )
}