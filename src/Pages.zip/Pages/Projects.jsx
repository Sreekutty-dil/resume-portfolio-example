import React from 'react';

export default function Projects(props) {
    return(
        <div className="container">
            <h1>Projects Page</h1>
        </div>
    )
}