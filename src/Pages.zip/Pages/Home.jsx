import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(props) {
    return(
        <div className="container">
            <div className="background">
                <div className="name">
                    <h1>Sreekutty.P.S</h1>
                    <h3>I'm a FullStack Developer</h3>
                    <div className="icons">
                        <Link to={'https://github.com/Sreekutty-dil'}></Link>
                    </div>
                </div>
            </div>
        </div>
    )
}